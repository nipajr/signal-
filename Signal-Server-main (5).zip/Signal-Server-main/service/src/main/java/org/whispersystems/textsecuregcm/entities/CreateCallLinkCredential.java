package org.whispersystems.textsecuregcm.entities;

public record CreateCallLinkCredential(byte[] credential, long redemptionTime){}
