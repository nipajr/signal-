package org.whispersystems.textsecuregcm.backup;

import java.io.IOException;

public class PublicKeyConflictException extends IOException {
}
