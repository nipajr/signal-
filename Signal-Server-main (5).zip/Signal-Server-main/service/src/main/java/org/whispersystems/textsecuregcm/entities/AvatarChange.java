package org.whispersystems.textsecuregcm.entities;

public enum AvatarChange {
  AVATAR_CHANGE_UNCHANGED,
  AVATAR_CHANGE_CLEAR,
  AVATAR_CHANGE_UPDATE
}
